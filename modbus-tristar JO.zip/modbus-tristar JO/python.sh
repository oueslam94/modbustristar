start python tristar-json.py
start python server.py
