# modbustristar
1) Open the modbustristar folder
2) do $ source setup.sh
3) watch the magic :) 
